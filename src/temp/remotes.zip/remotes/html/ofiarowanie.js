(function () {
  var app = document.getElementById('app');
  var toastWrap = document.createElement('div');
  toastWrap.className = 'toast-wrap';
  document.body.appendChild(toastWrap);

  var SETTINGS_KEY = 'ofiarowanie_openlp_22';
  var defaultConfig = { ip: location.hostname, port: Number(location.port || 4316), version: 'v2' };
  var config = loadConfig();
  var state = {
    connected: false,
    error: null,
    serviceItems: [],
    slides: [],
    currentServiceIndex: -1,
    currentSlideIndex: -1,
    searchPlugins: [],
    searchPlugin: 'songs',
    searchQuery: '',
    searchResults: [],
    searchError: null,
    displayMode: 'show'
  };
  var activeTab = 'connect';
  var pollTimer = null;

  function loadConfig() {
    try {
      var raw = localStorage.getItem(SETTINGS_KEY);
      if (raw) {
        var parsed = JSON.parse(raw);
        return {
          ip: parsed.ip || defaultConfig.ip,
          port: Number(parsed.port || defaultConfig.port),
          version: 'v2'
        };
      }
    } catch (e) {}
    return defaultConfig;
  }

  function saveConfig() {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(config));
  }

  function showToast(text, type) {
    var el = document.createElement('div');
    el.className = 'toast' + (type ? ' ' + type : '');
    el.textContent = text;
    toastWrap.appendChild(el);
    setTimeout(function () { if (el.parentNode) el.parentNode.removeChild(el); }, 3200);
  }

  function escapeHtml(v) {
    return String(v == null ? '' : v)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function currentOriginMatchesConfig() {
    return location.hostname === config.ip && Number(location.port || 4316) === Number(config.port || 4316);
  }

  function baseUrl() {
    return currentOriginMatchesConfig() ? location.origin : ('http://' + config.ip + ':' + config.port);
  }

  function jsonGet(url) {
    return new Promise(function (resolve, reject) {
      $.ajax({
        url: url,
        dataType: 'json',
        cache: false,
        timeout: 5000,
        success: function (data) { resolve(data); },
        error: function (_, status) {
          if (status === 'timeout') return reject(new Error('Timeout — brak odpowiedzi z OpenLP'));
          reject(new Error('Brak połączenia z OpenLP — sprawdź IP, port i Remote API.'));
        }
      });
    });
  }

  function encodeData(obj) {
    return encodeURIComponent(JSON.stringify(obj));
  }

  async function getSearchPlugins() {
    var data = await jsonGet(baseUrl() + '/api/plugin/search');
    return (data.results && data.results.items) || [];
  }

  async function getServiceItems() {
    var data = await jsonGet(baseUrl() + '/api/service/list');
    return (data.results && data.results.items) || [];
  }

  async function getSlides() {
    var data = await jsonGet(baseUrl() + '/api/controller/live/text');
    return (data.results && data.results.slides) || [];
  }

  async function pollInfo() {
    var data = await jsonGet(baseUrl() + '/api/poll');
    return data.results || {};
  }

  async function action(url) {
    await jsonGet(baseUrl() + url);
  }

  async function setServiceItem(id) {
    await jsonGet(baseUrl() + '/api/service/set?data=' + encodeData({ request: { id: id } }));
  }

  async function setSlide(id) {
    await jsonGet(baseUrl() + '/api/controller/live/set?data=' + encodeData({ request: { id: id } }));
  }

  async function searchItems(plugin, text) {
    var url = plugin === 'songs'
      ? (baseUrl() + '/api/songs/search?data=' + encodeData({ request: { text: text } }))
      : (baseUrl() + '/api/' + plugin + '/search?data=' + encodeData({ request: { text: text } }));
    var data = await jsonGet(url);
    return (data.results && data.results.items) || [];
  }

  async function addToService(plugin, id) {
    await jsonGet(baseUrl() + '/api/' + plugin + '/add?data=' + encodeData({ request: { id: id } }));
  }

  async function goLive(plugin, id) {
    await jsonGet(baseUrl() + '/api/' + plugin + '/live?data=' + encodeData({ request: { id: id } }));
  }

  async function refreshData() {
    var info = await pollInfo();
    var serviceItems = await getServiceItems();
    var slides = await getSlides();
    var plugins = state.searchPlugins.length ? state.searchPlugins : await getSearchPlugins();
    var currentServiceIndex = -1;
    var currentSlideIndex = -1;
    for (var i = 0; i < serviceItems.length; i++) {
      if (serviceItems[i].selected) { currentServiceIndex = i; break; }
    }
    for (var s = 0; s < slides.length; s++) {
      if (slides[s].selected) { currentSlideIndex = s; break; }
    }
    state.connected = true;
    state.error = null;
    state.serviceItems = serviceItems;
    state.slides = slides;
    state.currentServiceIndex = currentServiceIndex;
    state.currentSlideIndex = currentSlideIndex;
    state.searchPlugins = plugins;
    if (!state.searchPlugin && plugins.length) state.searchPlugin = plugins[0][0];
    state.displayMode = info.blank ? 'blank' : info.theme ? 'theme' : info.display ? 'desktop' : 'show';
    render();
  }

  function startPolling() {
    stopPolling();
    pollTimer = setInterval(function () {
      refreshData().catch(function () {});
    }, 1000);
  }

  function stopPolling() {
    if (pollTimer) clearInterval(pollTimer);
    pollTimer = null;
  }

  async function connect() {
    saveConfig();
    await refreshData();
    startPolling();
    activeTab = 'service';
    render();
    showToast('Połączono z OpenLP');
  }

  function disconnect() {
    stopPolling();
    state.connected = false;
    state.error = null;
    state.serviceItems = [];
    state.slides = [];
    state.currentServiceIndex = -1;
    state.currentSlideIndex = -1;
    render();
  }

  function normalizeSearch(items) {
    var out = [];
    for (var i = 0; i < items.length; i++) {
      var value = items[i];
      if ($.isArray(value)) {
        out.push({ id: value[0], title: value[1] });
      } else if (value && typeof value === 'object') {
        out.push({ id: value.id, title: value.title || value.name || value.text || ('Pozycja ' + (i + 1)) });
      }
    }
    return out;
  }

  async function runSearch() {
    if (!state.searchQuery.trim()) return;
    state.searchError = null;
    state.searchResults = [];
    render();
    try {
      var items = await searchItems(state.searchPlugin, state.searchQuery.trim());
      state.searchResults = normalizeSearch(items);
      if (!state.searchResults.length) state.searchError = 'Brak wyników';
      render();
    } catch (e) {
      state.searchError = e.message || 'Błąd wyszukiwania';
      render();
    }
  }

  function bindEvents() {
    $('[data-tab]').off('click').on('click', function () {
      activeTab = $(this).data('tab');
      render();
    });
    $('#cfg-ip').off('input').on('input', function () { config.ip = this.value; saveConfig(); });
    $('#cfg-port').off('input').on('input', function () { config.port = Number(this.value || 4316); saveConfig(); });
    $('#btn-connect').off('click').on('click', function () {
      connect().catch(function (e) { state.error = e.message; render(); });
    });
    $('#btn-disconnect').off('click').on('click', disconnect);
    $('#btn-refresh').off('click').on('click', function () {
      refreshData().catch(function (e) { state.error = e.message; render(); });
    });
    $('#btn-prev-item').off('click').on('click', function () { action('/api/service/previous').then(refreshData).catch(handleError); });
    $('#btn-next-item').off('click').on('click', function () { action('/api/service/next').then(refreshData).catch(handleError); });
    $('#btn-prev-slide').off('click').on('click', function () { action('/api/controller/live/previous').then(refreshData).catch(handleError); });
    $('#btn-next-slide').off('click').on('click', function () { action('/api/controller/live/next').then(refreshData).catch(handleError); });
    $('#btn-display-show').off('click').on('click', function () { action('/api/display/show').then(refreshData).catch(handleError); });
    $('#btn-display-blank').off('click').on('click', function () { action('/api/display/blank').then(refreshData).catch(handleError); });
    $('#btn-display-desktop').off('click').on('click', function () { action('/api/display/desktop').then(refreshData).catch(handleError); });
    $('#btn-display-theme').off('click').on('click', function () { action('/api/display/theme').then(refreshData).catch(handleError); });
    $('#search-plugin').off('change').on('change', function () { state.searchPlugin = this.value; });
    $('#search-query').off('input').on('input', function () { state.searchQuery = this.value; });
    $('#btn-search').off('click').on('click', function () { runSearch().catch(handleError); });
    $('.service-item').off('click').on('click', function () { setServiceItem(Number($(this).data('id'))).then(refreshData).catch(handleError); });
    $('.slide-item').off('click').on('click', function () { setSlide(Number($(this).data('id'))).then(refreshData).catch(handleError); });
    $('.search-add').off('click').on('click', function (e) { e.stopPropagation(); addToService(state.searchPlugin, $(this).data('id')).then(function () { showToast('Dodano do nabożeństwa'); refreshData(); }).catch(handleError); });
    $('.search-live').off('click').on('click', function (e) { e.stopPropagation(); goLive(state.searchPlugin, $(this).data('id')).then(function () { showToast('Wysłano na żywo'); refreshData(); }).catch(handleError); });
  }

  function handleError(e) {
    state.error = e.message || 'Błąd';
    render();
    showToast(state.error, 'error');
  }

  function renderServiceItems() {
    if (!state.serviceItems.length) return '<div class="muted">Brak danych.</div>';
    var html = ['<div class="list">'];
    for (var i = 0; i < state.serviceItems.length; i++) {
      var item = state.serviceItems[i];
      html.push('<div class="list-item service-item ' + (i === state.currentServiceIndex ? 'active' : '') + '" data-id="' + i + '">');
      html.push('<div><div class="list-item-title">' + escapeHtml(item.title || ('Pozycja ' + (i + 1))) + '</div>');
      html.push('<div class="list-item-meta">' + escapeHtml(item.plugin || '') + (item.notes ? ' • ' + escapeHtml(item.notes) : '') + '</div></div>');
      html.push(i === state.currentServiceIndex ? '<span class="live-pill"><span class="tiny-dot bg-success"></span>LIVE</span>' : '<span class="tag">#' + (i + 1) + '</span>');
      html.push('</div>');
    }
    html.push('</div>');
    return html.join('');
  }

  function renderSlides() {
    if (!state.slides.length) return '<div class="muted">Brak danych.</div>';
    var html = ['<div class="list">'];
    for (var i = 0; i < state.slides.length; i++) {
      var slide = state.slides[i];
      var label = (slide.tag ? slide.tag + ': ' : '') + (slide.title || slide.text || ('Slajd ' + (i + 1)));
      html.push('<div class="list-item slide-item ' + (i === state.currentSlideIndex ? 'active' : '') + '" data-id="' + i + '">');
      html.push('<div><div class="list-item-title">' + escapeHtml(label) + '</div>');
      if (slide.slide_notes) html.push('<div class="list-item-meta">' + escapeHtml(slide.slide_notes) + '</div>');
      html.push('</div>');
      html.push(i === state.currentSlideIndex ? '<span class="live-pill"><span class="tiny-dot bg-success"></span>LIVE</span>' : '<span class="tag">#' + (i + 1) + '</span>');
      html.push('</div>');
    }
    html.push('</div>');
    return html.join('');
  }

  function renderSearchResults() {
    if (state.searchError) return '<div class="muted">' + escapeHtml(state.searchError) + '</div>';
    if (!state.searchResults.length) return '<div class="muted">Wpisz frazę i kliknij Szukaj.</div>';
    var html = ['<div class="list">'];
    for (var i = 0; i < state.searchResults.length; i++) {
      var item = state.searchResults[i];
      html.push('<div class="list-item">');
      html.push('<div><div class="list-item-title">' + escapeHtml(item.title) + '</div><div class="list-item-meta">ID: ' + escapeHtml(item.id) + '</div></div>');
      html.push('<div class="button-row"><button class="btn outline search-add" data-id="' + escapeHtml(item.id) + '">Dodaj</button><button class="btn search-live" data-id="' + escapeHtml(item.id) + '">Na żywo</button></div>');
      html.push('</div>');
    }
    html.push('</div>');
    return html.join('');
  }

  function pluginOptions() {
    if (!state.searchPlugins.length) return '<option value="songs">songs</option>';
    var out = [];
    for (var i = 0; i < state.searchPlugins.length; i++) {
      var p = state.searchPlugins[i];
      out.push('<option value="' + escapeHtml(p[0]) + '"' + (state.searchPlugin === p[0] ? ' selected' : '') + '>' + escapeHtml(p[1]) + '</option>');
    }
    return out.join('');
  }

  function render() {
    app.innerHTML = [
      '<div class="shell">',
        '<div class="page-grid">',
          '<div class="panel-column">',
            '<div class="tabs">',
              '<div class="tabs-list">',
                tabButton('connect', 'Połączenie'),
                tabButton('service', 'Nabożeństwo'),
                tabButton('slides', 'Slajdy'),
                tabButton('search', 'Szukaj'),
                tabButton('help', 'Pomoc'),
              '</div>',
              tabContent('connect',
                '<div class="card scroll-card"><div class="card-header">Połączenie z OpenLP 2.2</div><div class="card-body">' +
                  '<div class="status-row"><span class="status-dot ' + (state.connected ? 'bg-success' : 'bg-destructive') + '"></span><span>' + (state.connected ? 'Połączono z OpenLP' : 'Rozłączono') + '</span></div>' +
                  (state.error ? '<div style="margin-top:12px" class="error-box">' + escapeHtml(state.error) + '</div>' : '') +
                  '<div class="field" style="margin-top:12px"><label>Adres IP</label><input id="cfg-ip" class="input" value="' + escapeHtml(config.ip) + '" /></div>' +
                  '<div class="two-cols"><div class="field"><label>Port</label><input id="cfg-port" class="input" type="number" value="' + escapeHtml(config.port) + '" /></div><div class="field"><label>Wersja</label><input class="input" value="OpenLP 2.2" disabled /></div></div>' +
                  '<div class="button-row">' +
                    (state.connected ? '<button id="btn-disconnect" class="btn outline flex-1">Rozłącz</button>' : '<button id="btn-connect" class="btn flex-1">Połącz</button>') +
                    '<button id="btn-refresh" class="btn ghost">Odśwież</button>' +
                  '</div>' +
                  '<p class="muted" style="margin-top:12px">To działa bez dodatkowego mostu, ponieważ panel jest hostowany przez OpenLP z tego samego originu.</p>' +
                '</div></div>'
              ),
              tabContent('service',
                '<div class="card scroll-card"><div class="card-header">Nabożeństwo</div><div class="card-list">' + renderServiceItems() + '</div></div>'
              ),
              tabContent('slides',
                '<div class="card scroll-card"><div class="card-header">Slajdy</div><div class="card-list">' + renderSlides() + '</div></div>'
              ),
              tabContent('search',
                '<div class="card scroll-card"><div class="card-header">Szukaj i dodaj</div><div class="card-body">' +
                  '<div class="field"><label>Typ</label><select id="search-plugin" class="select">' + pluginOptions() + '</select></div>' +
                  '<div class="field"><label>Fraza</label><input id="search-query" class="input" value="' + escapeHtml(state.searchQuery) + '" placeholder="np. Błogosław duszo moja Pana" /></div>' +
                  '<button id="btn-search" class="btn full">Szukaj</button>' +
                '</div><div class="card-list">' + renderSearchResults() + '</div></div>'
              ),
              tabContent('help',
                '<div class="card scroll-card"><div class="card-header">Pomoc</div><div class="card-body"><ol class="help-list">' +
                  '<li>Włącz plugin Remote w OpenLP i upewnij się, że działa na porcie 4316.</li>' +
                  '<li>Skopiuj pliki <code>ofiarowanie.html</code>, <code>ofiarowanie.css</code> i <code>ofiarowanie.js</code> do folderu <code>plugins\\remotes\\html</code>.</li>' +
                  '<li>Wejdź na adres <code>/files/ofiarowanie.html</code>.</li>' +
                  '<li>Oryginalny widok OpenLP zostaje bez zmian pod <code>/</code>, <code>/stage</code> i <code>/main</code>.</li>' +
                '</ol></div></div>'
              ),
            '</div>',
          '</div>',
          '<div class="preview-column">',
            '<div class="card preview-card">',
              '<div class="card-header">Podgląd główny</div>',
              '<div class="preview-frame-wrap"><iframe class="preview-frame" src="/main" title="Main preview"></iframe></div>',
              '<div class="controls">',
                '<div class="control-card"><div class="control-title">Slajdy</div><div class="button-row"><button id="btn-prev-slide" class="btn outline flex-1">Poprzedni</button><button id="btn-next-slide" class="btn flex-1">Następny</button></div></div>',
                '<div class="control-card"><div class="control-title">Nabożeństwo</div><div class="button-row"><button id="btn-prev-item" class="btn outline flex-1">Poprzedni</button><button id="btn-next-item" class="btn flex-1">Następny</button></div></div>',
                '<div class="control-card"><div class="control-title">Ekran</div><div class="button-row"><button id="btn-display-blank" class="btn outline flex-1">Wygaś</button><button id="btn-display-show" class="btn flex-1">Pokaż</button></div></div>',
                '<div class="control-card"><div class="control-title">Tryb wyjścia</div><div class="button-row"><button id="btn-display-desktop" class="btn outline flex-1">Pulpit</button><button id="btn-display-theme" class="btn outline flex-1">Motyw</button></div></div>',
              '</div>',
            '</div>',
          '</div>',
        '</div>',
      '</div>'
    ].join('');
    bindEvents();
  }

  function tabButton(name, label) {
    return '<button class="tab-trigger ' + (activeTab === name ? 'active' : '') + '" data-tab="' + name + '">' + label + '</button>';
  }

  function tabContent(name, inner) {
    return '<div class="tab-content ' + (activeTab === name ? 'active' : '') + '">' + inner + '</div>';
  }

  function boot() {
    window.jQuery ? render() : loadJquery();
  }

  function loadJquery() {
    var s = document.createElement('script');
    s.src = '/files/jquery.min.js';
    s.onload = render;
    document.head.appendChild(s);
  }

  boot();
})();
