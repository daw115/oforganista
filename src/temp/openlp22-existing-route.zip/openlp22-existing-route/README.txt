Ta paczka robi 2 rzeczy:
1. dodaje trasę /ofiarowanie -> ofiarowanie.html
2. nie dodaje nowego endpointu /api/ofiarowanie/song-search
   tylko wykorzystuje istniejące /api/songs/search, ale po stronie Pythona
   specjalnie dla pluginu songs czyta songs.sqlite bezpośrednio z dysku.

Podmień:
- remotes/lib/httprouter.py
- skopiuj remotes/html/ofiarowanie.html
- skopiuj remotes/html/ofiarowanie.css
- skopiuj remotes/html/ofiarowanie.js

Testy po restarcie OpenLP:
- http://IP:4316/ofiarowanie
- http://IP:4316/api/songs/search?data=%7B%22request%22%3A%7B%22text%22%3A%22abba%22%7D%7D

Drugi adres powinien zwrócić JSON z wynikami.
